# Iraq77 – Login Web (Render)
واجهة دخول بسيطة (Nick + Password) ثم فتح شات الويب مباشرة إلى #iraq77 عبر KiwiIRC.

## نشر على Render
- Build Command: `npm install`
- Start Command: `npm start`

## إعداد
افتح `public/index.html` وعدّل:
```js
const SERVER = "irc.libera.chat"; // لاحقًا ضع irc.iraq77.net
const CHANNEL = "#iraq77";
const PAGE_PASSWORD = "iraqpass77";
```

> ملاحظة: كلمة المرور تخص الواجهة فقط وليست NickServ.
